package com.zhongzhang.randomstudent.tool;

public interface ClickDeleteStudent {
	public abstract void onDeleteStudent(int whicth);

}
