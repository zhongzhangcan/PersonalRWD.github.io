package com.zhongzhang.randomstudent.tool;

public interface ClickPhoto {
	public abstract void onClickPhoto(int whicth);
}
